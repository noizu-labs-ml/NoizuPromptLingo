# NPL MCP Server

Multi-agent collaboration tools for the NPL (Noizu Prompt Lingua) framework, implemented as an MCP server.

## Features

Based on the [PRD Suite](./docs/prds/):

| PRD | Feature | Status |
|-----|---------|--------|
| 01 | Discovery - Semantic search for tools/resources | 🚧 |
| 02 | Session Auth - JWT sessions with PSK | 🚧 |
| 03 | Profiles - Tool bundles | 🚧 |
| 04 | NPL Loader - Delta semantics loading | 🚧 |
| 05 | Artifacts - Versioned storage with review | 🚧 |
| 06 | Persona - Worklog, journal, KB, teams | 🚧 |
| 07 | Chat - Slack/Discord-style messaging | 🚧 |
| 08 | Ticketing - PM tool integration | 🚧 |
| 09 | Files - Dump, tree, search utilities | ✅ |
| 10 | Visualization - FIM tool routing | 🚧 |
| 11 | Orchestration - Multi-agent workflows | 🚧 |

## Quick Start

```bash
# Clone and setup
git clone <repo>
cd npl-mcp
uv sync

# Run tests
uv run pytest

# Run server (development)
uv run fastmcp dev src/npl_mcp/server.py

# Run server (production)
uv run python -m npl_mcp.server
```

## Configuration

Copy `config/default.yaml` to `config/local.yaml` and customize:

```yaml
server:
  data_dir: "./data"

chat:
  default_backend: "internal"
  backends:
    slack:
      enabled: true
      auth:
        token: "${SLACK_BOT_TOKEN}"

ticketing:
  default_backend: "jira"
  backends:
    jira:
      enabled: true
      base_url: "${JIRA_URL}"
```

## MCP Client Setup

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "npl": {
      "command": "uv",
      "args": ["run", "python", "-m", "npl_mcp.server"],
      "cwd": "/path/to/npl-mcp"
    }
  }
}
```

## Development

```bash
# Install dev dependencies
uv sync --all-extras

# Run tests with coverage
uv run pytest --cov=npl_mcp

# Type check
uv run mypy src/

# Lint
uv run ruff check src/
uv run ruff format src/
```

## Project Structure

```
npl-mcp/
├── src/npl_mcp/
│   ├── server.py          # FastMCP entry point
│   ├── config.py          # Configuration loading
│   ├── db/                # Database management
│   ├── tools/             # MCP tool implementations
│   │   ├── discovery.py   # PRD 01
│   │   ├── session.py     # PRD 02
│   │   ├── files.py       # PRD 09 ✅
│   │   └── ...
│   └── adapters/          # External service adapters
│       ├── chat/          # Slack, Discord, etc.
│       └── ticketing/     # Jira, ClickUp, etc.
├── tests/
├── config/
└── data/                  # Runtime data (gitignored)
```

## License

MIT
