"""NPL MCP Server - Main entry point."""

from fastmcp import FastMCP

from npl_mcp.config import load_config
from npl_mcp.db.base import Database

# Initialize server
mcp = FastMCP(
    name="npl-mcp",
    version="0.1.0",
    description="NPL MCP Discovery System - Multi-agent collaboration tools",
)

# Global instances (initialized on startup)
db: Database | None = None
config: dict | None = None


@mcp.on_startup
async def startup():
    """Initialize database and load configuration."""
    global db, config
    
    config = load_config()
    db = Database(config.get("server", {}).get("data_dir", "./data"))
    await db.migrate()


# Import and register tools
from npl_mcp.tools import discovery  # noqa: E402, F401
from npl_mcp.tools import files  # noqa: E402, F401
from npl_mcp.tools import session  # noqa: E402, F401


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
