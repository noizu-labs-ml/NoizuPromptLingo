"""File utility tools for NPL MCP (PRD 09)."""

import fnmatch
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from npl_mcp.server import mcp


@dataclass
class FileDumpResult:
    """Result of file_dump operation."""
    path: str
    files_dumped: int
    files_skipped: int
    total_lines: int
    total_bytes: int
    content: str
    skipped_files: list[dict]


@dataclass
class FileTreeResult:
    """Result of file_tree operation."""
    path: str
    tree: str
    total_files: int
    total_dirs: int


@dataclass
class DirectoryDepth:
    """Directory with depth information."""
    path: str
    depth: int


def _get_gitignore_patterns(path: Path) -> list[str]:
    """Load .gitignore patterns from path."""
    patterns = []
    gitignore = path / ".gitignore"
    if gitignore.exists():
        with open(gitignore) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    patterns.append(line)
    return patterns


def _should_ignore(file_path: Path, base_path: Path, patterns: list[str]) -> bool:
    """Check if file should be ignored based on patterns."""
    relative = file_path.relative_to(base_path)
    rel_str = str(relative)
    
    for pattern in patterns:
        if fnmatch.fnmatch(rel_str, pattern):
            return True
        if fnmatch.fnmatch(file_path.name, pattern):
            return True
    return False


def _is_binary(file_path: Path) -> bool:
    """Check if file is binary."""
    binary_extensions = {
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp",
        ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
        ".zip", ".tar", ".gz", ".bz2", ".7z", ".rar",
        ".exe", ".dll", ".so", ".dylib",
        ".pyc", ".pyo", ".class",
        ".db", ".sqlite", ".sqlite3",
    }
    return file_path.suffix.lower() in binary_extensions


@mcp.tool(tags=["files", "dump"])
async def file_dump(
    path: str,
    glob_filter: str | None = None,
    exclude_patterns: list[str] | None = None,
    include_hidden: bool = False,
    max_file_size_kb: int = 500,
    output_format: Literal["markdown", "xml"] = "markdown",
) -> FileDumpResult:
    """Dump file contents with headers, respecting .gitignore.
    
    Args:
        path: Target directory or file
        glob_filter: Optional glob pattern (e.g., "*.py")
        exclude_patterns: Additional patterns to exclude
        include_hidden: Include dotfiles
        max_file_size_kb: Skip files larger than this
        output_format: Output format (markdown or xml)
    
    Returns:
        FileDumpResult with content and statistics
    """
    base_path = Path(path).resolve()
    
    if not base_path.exists():
        raise ValueError(f"Path does not exist: {path}")
    
    # Collect ignore patterns
    ignore_patterns = _get_gitignore_patterns(base_path)
    if exclude_patterns:
        ignore_patterns.extend(exclude_patterns)
    
    # Default excludes
    ignore_patterns.extend([
        "node_modules/", "__pycache__/", ".git/", "*.pyc", ".DS_Store"
    ])
    
    files_dumped = 0
    files_skipped = 0
    total_lines = 0
    total_bytes = 0
    content_parts = []
    skipped_files = []
    
    # Collect files
    if base_path.is_file():
        files = [base_path]
    else:
        files = sorted(base_path.rglob("*"))
    
    for file_path in files:
        if not file_path.is_file():
            continue
        
        # Skip hidden files unless requested
        if not include_hidden and file_path.name.startswith("."):
            continue
        
        # Check glob filter
        if glob_filter and not fnmatch.fnmatch(file_path.name, glob_filter):
            continue
        
        # Check ignore patterns
        if _should_ignore(file_path, base_path, ignore_patterns):
            skipped_files.append({"path": str(file_path), "reason": "gitignore"})
            files_skipped += 1
            continue
        
        # Check binary
        if _is_binary(file_path):
            skipped_files.append({"path": str(file_path), "reason": "binary"})
            files_skipped += 1
            continue
        
        # Check size
        size_kb = file_path.stat().st_size / 1024
        if size_kb > max_file_size_kb:
            skipped_files.append({"path": str(file_path), "reason": "too_large"})
            files_skipped += 1
            continue
        
        # Read file
        try:
            content = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            try:
                content = file_path.read_text(encoding="latin-1")
            except Exception:
                skipped_files.append({"path": str(file_path), "reason": "encoding"})
                files_skipped += 1
                continue
        
        relative_path = file_path.relative_to(base_path) if base_path.is_dir() else file_path.name
        lines = content.count("\n") + 1
        
        if output_format == "markdown":
            content_parts.append(f"# {relative_path}\n---\n{content}\n* * *\n")
        else:  # xml
            content_parts.append(
                f'<file path="{relative_path}">\n'
                f"<content><![CDATA[\n{content}\n]]></content>\n"
                f"</file>\n"
            )
        
        files_dumped += 1
        total_lines += lines
        total_bytes += len(content.encode("utf-8"))
    
    return FileDumpResult(
        path=str(base_path),
        files_dumped=files_dumped,
        files_skipped=files_skipped,
        total_lines=total_lines,
        total_bytes=total_bytes,
        content="\n".join(content_parts),
        skipped_files=skipped_files[:20],  # Limit to first 20
    )


@mcp.tool(tags=["files", "tree"])
async def file_tree(
    path: str = ".",
    max_depth: int | None = None,
    show_size: bool = False,
    dirs_only: bool = False,
    git_tracked_only: bool = True,
) -> FileTreeResult:
    """Display directory tree.
    
    Args:
        path: Target directory
        max_depth: Maximum depth to display
        show_size: Show file sizes
        dirs_only: Only show directories
        git_tracked_only: Only show Git-tracked files
    
    Returns:
        FileTreeResult with formatted tree
    """
    base_path = Path(path).resolve()
    
    if not base_path.exists():
        raise ValueError(f"Path does not exist: {path}")
    
    if git_tracked_only:
        # Use git ls-files for tracked files
        try:
            result = subprocess.run(
                ["git", "ls-files"],
                cwd=base_path,
                capture_output=True,
                text=True,
                check=True,
            )
            tracked_files = set(result.stdout.strip().split("\n"))
        except subprocess.CalledProcessError:
            tracked_files = None
    else:
        tracked_files = None
    
    # Build tree structure
    tree_lines = [base_path.name + "/"]
    total_files = 0
    total_dirs = 0
    
    def add_entry(entry_path: Path, prefix: str, depth: int):
        nonlocal total_files, total_dirs
        
        if max_depth and depth > max_depth:
            return
        
        entries = sorted(entry_path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        
        for i, entry in enumerate(entries):
            # Skip hidden
            if entry.name.startswith("."):
                continue
            
            # Skip if not tracked
            if tracked_files is not None:
                rel_path = str(entry.relative_to(base_path))
                if entry.is_file() and rel_path not in tracked_files:
                    continue
            
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            
            if entry.is_dir():
                total_dirs += 1
                if not dirs_only:
                    tree_lines.append(f"{prefix}{connector}{entry.name}/")
                else:
                    tree_lines.append(f"{prefix}{connector}{entry.name}/")
                
                new_prefix = prefix + ("    " if is_last else "│   ")
                add_entry(entry, new_prefix, depth + 1)
            elif not dirs_only:
                total_files += 1
                size_str = ""
                if show_size:
                    size = entry.stat().st_size
                    if size < 1024:
                        size_str = f" ({size}B)"
                    elif size < 1024 * 1024:
                        size_str = f" ({size // 1024}KB)"
                    else:
                        size_str = f" ({size // (1024 * 1024)}MB)"
                
                tree_lines.append(f"{prefix}{connector}{entry.name}{size_str}")
    
    if base_path.is_dir():
        add_entry(base_path, "", 0)
    
    tree_lines.append(f"\n{total_dirs} directories, {total_files} files")
    
    return FileTreeResult(
        path=str(base_path),
        tree="\n".join(tree_lines),
        total_files=total_files,
        total_dirs=total_dirs,
    )


@mcp.tool(tags=["files", "tree"])
async def file_tree_depth(path: str) -> list[DirectoryDepth]:
    """List directories with nesting depth levels.
    
    Args:
        path: Target directory
    
    Returns:
        List of directories with depth information
    """
    base_path = Path(path).resolve()
    
    if not base_path.exists():
        raise ValueError(f"Path does not exist: {path}")
    
    result = [DirectoryDepth(path=".", depth=0)]
    
    for entry in sorted(base_path.rglob("*")):
        if entry.is_dir() and not entry.name.startswith("."):
            relative = entry.relative_to(base_path)
            depth = len(relative.parts)
            result.append(DirectoryDepth(path=str(relative), depth=depth))
    
    return result
