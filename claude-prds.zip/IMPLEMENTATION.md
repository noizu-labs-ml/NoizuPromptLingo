# NPL MCP Implementation Roadmap

Implementation guide for the NPL MCP Discovery System based on the PRD suite.

---

## Project Structure

```
npl-mcp/
├── pyproject.toml
├── src/
│   └── npl_mcp/
│       ├── __init__.py
│       ├── server.py                 # FastMCP server entry
│       ├── config.py                 # Configuration loading
│       ├── db/
│       │   ├── __init__.py
│       │   ├── base.py               # SQLite connection management
│       │   ├── migrations/           # Schema migrations
│       │   └── models.py             # Shared data models
│       ├── middleware/
│       │   ├── __init__.py
│       │   ├── auth.py               # Session validation (02)
│       │   ├── visibility.py         # Tag-based tool hiding
│       │   └── iteration.py          # Iteration token tracking
│       ├── tools/
│       │   ├── __init__.py
│       │   ├── discovery.py          # 01-discovery
│       │   ├── session.py            # 02-session-auth
│       │   ├── profiles.py           # 03-profiles
│       │   ├── npl_loader.py         # 04-npl-loader
│       │   ├── artifacts.py          # 05-artifacts
│       │   ├── persona.py            # 06-persona
│       │   ├── chat.py               # 07-chat
│       │   ├── todo.py               # 08-todo
│       │   ├── files.py              # 09-files
│       │   ├── viz.py                # 10-viz
│       │   └── orchestration.py      # 11-orchestration
│       └── adapters/
│           ├── __init__.py
│           ├── chat/
│           │   ├── base.py           # ChatAdapter ABC
│           │   ├── internal.py       # SQLite + Redis
│           │   ├── slack.py
│           │   └── discord.py
│           └── ticketing/
│               ├── base.py           # TicketingAdapter ABC
│               ├── jira.py
│               ├── clickup.py
│               ├── linear.py
│               ├── monday.py
│               └── basecamp.py
├── tests/
│   ├── conftest.py
│   ├── test_discovery.py
│   ├── test_session.py
│   └── ...
├── data/                             # Runtime data (gitignored)
│   ├── npl-mcp.db
│   └── artifacts/
└── config/
    ├── default.yaml
    └── example.yaml
```

---

## Phase 1: Foundation (Week 1-2)

### 1.1 Project Setup
```bash
# Initialize project
mkdir npl-mcp && cd npl-mcp
uv init
uv add fastmcp aiosqlite pydantic pyyaml

# Dev dependencies
uv add --dev pytest pytest-asyncio ruff mypy
```

### 1.2 Core Infrastructure

**Priority files:**
1. `src/npl_mcp/db/base.py` - Database connection pool
2. `src/npl_mcp/config.py` - YAML config loading
3. `src/npl_mcp/server.py` - FastMCP server skeleton

**Database setup:**
```python
# src/npl_mcp/db/base.py
import aiosqlite
from contextlib import asynccontextmanager

class Database:
    def __init__(self, path: str = "./data/npl-mcp.db"):
        self.path = path
        
    @asynccontextmanager
    async def connection(self):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            yield db
            
    async def migrate(self):
        """Run all migrations"""
        async with self.connection() as db:
            # Create tables from PRD schemas
            pass
```

### 1.3 Session Auth (02) - Optional but Recommended First
```python
# src/npl_mcp/tools/session.py
from fastmcp import FastMCP
from dataclasses import dataclass

@dataclass
class SessionClaims:
    agent_id: str
    roles: list[str]
    scopes: list[str]
    exp: int
    
@mcp.tool(tags=["auth"])
async def session_init(psk_id: str, timestamp: str, signature: str) -> SessionResult:
    """Initialize authenticated session"""
    # Verify HMAC signature
    # Generate JWT
    # Return session token
```

### 1.4 Discovery Tool (01)
```python
# src/npl_mcp/tools/discovery.py
from fastmcp import FastMCP

@mcp.tool(tags=["discovery", "public"])
async def discovery(
    action: Literal["search", "fetch", "categories", "refresh", "known"],
    # ... parameters from PRD
) -> DiscoveryResult:
    """Unified discovery interface"""
```

### 1.5 File Utilities (09) - Standalone, Easy Win
```python
# src/npl_mcp/tools/files.py
import subprocess
from pathlib import Path

@mcp.tool(tags=["files"])
async def file_dump(
    path: str,
    glob_filter: str | None = None,
    # ... from PRD
) -> FileDumpResult:
    """Dump file contents respecting .gitignore"""
```

---

## Phase 2: Content Management (Week 3-4)

### 2.1 Artifacts (05)
- Implement revision storage
- Add review workflow
- Support overlay annotations

### 2.2 Profiles (03)
- Profile CRUD
- Profile inheritance
- Discovery integration

### 2.3 NPL Loader (04)
- Delta semantics engine
- Priority filtering
- Search path resolution

---

## Phase 3: Collaboration (Week 5-6)

### 3.1 Persona Tools (06)
- Worklog/journal
- Memory with vector search
- Knowledge base with approval workflow
- Team operations

### 3.2 Chat Rooms (07)
**Internal backend first:**
```python
# src/npl_mcp/adapters/chat/internal.py
class InternalChatAdapter(ChatAdapter):
    async def send_message(self, room_id: str, content: str, **kwargs):
        # Insert into chat_events table
        # Publish to Redis if available
        pass
```

**Then external adapters:**
- Slack (Bot API)
- Discord (Bot + Gateway)

### 3.3 Todo/Ticketing (08)
**Start with one adapter:**
```python
# src/npl_mcp/adapters/ticketing/jira.py
class JiraAdapter(TicketingAdapter):
    async def create_task(self, task: TaskCreate) -> TaskResult:
        # Map fields to Jira format
        # Call Jira REST API
        pass
```

---

## Phase 4: Advanced (Week 7-8)

### 4.1 Visualization Routing (10)
- Use case detection
- Tool scoring
- Style guide generation

### 4.2 Agent Orchestration (11)
- Workflow definition DSL
- Execution engine
- Checkpoint validation

---

## Testing Strategy

### Unit Tests
```python
# tests/test_discovery.py
import pytest
from npl_mcp.tools.discovery import discovery

@pytest.mark.asyncio
async def test_discovery_search():
    result = await discovery(
        action="search",
        query="code review",
        item_types=["tool"]
    )
    assert result.total_count >= 0
```

### Integration Tests
```python
# tests/test_integration.py
@pytest.mark.asyncio
async def test_full_workflow():
    # Create artifact
    artifact = await artifact_create(name="test", ...)
    
    # Request review
    review = await artifact_review_request(artifact_id=artifact.id, ...)
    
    # Add comment
    await artifact_comment_add(artifact_id=artifact.id, ...)
    
    # Complete review
    await artifact_review_respond(review_id=review.id, decision="approved")
```

---

## Configuration Example

```yaml
# config/default.yaml
server:
  name: "npl-mcp"
  version: "0.1.0"
  data_dir: "./data"

auth:
  enabled: true
  psk_file: "./config/psk.yaml"
  session_ttl_hours: 1

discovery:
  cache_ttl_seconds: 300
  embedding_model: "text-embedding-3-small"

npl:
  home: "./.npl"
  search_paths:
    - "./.npl"
    - "~/.npl"
    - "/etc/npl"

chat:
  default_backend: "internal"
  backends:
    internal:
      enabled: true
      database_path: "./data/chat.db"
    slack:
      enabled: false

ticketing:
  default_backend: "jira"
  backends:
    jira:
      enabled: true
      base_url: "${JIRA_URL}"
      auth:
        type: "api_token"

visualization:
  default_theme: "light"
  artifact_path: "./artifacts/viz"
```

---

## Quick Start Commands

```bash
# Setup
git clone <repo>
cd npl-mcp
uv sync

# Initialize database
uv run python -m npl_mcp.db.migrate

# Run server (for testing)
uv run fastmcp dev src/npl_mcp/server.py

# Run tests
uv run pytest

# Type check
uv run mypy src/

# Lint
uv run ruff check src/
```

---

## MCP Client Configuration

```json
{
  "mcpServers": {
    "npl": {
      "command": "uv",
      "args": ["run", "python", "-m", "npl_mcp.server"],
      "cwd": "/path/to/npl-mcp",
      "env": {
        "NPL_CONFIG": "/path/to/config.yaml"
      }
    }
  }
}
```

---

## Milestones

| Week | Deliverable | PRDs |
|------|-------------|------|
| 1 | Project skeleton, DB, config | — |
| 2 | Session auth, Discovery, Files | 01, 02, 09 |
| 3 | Artifacts, Profiles | 03, 05 |
| 4 | NPL Loader | 04 |
| 5 | Persona tools | 06 |
| 6 | Chat (internal), Todo (Jira) | 07, 08 |
| 7 | Chat adapters, Todo adapters | 07, 08 |
| 8 | Viz routing, Orchestration | 10, 11 |

---

## Success Criteria

- [ ] All 11 PRDs implemented with >80% tool coverage
- [ ] Unit test coverage >70%
- [ ] Integration tests for cross-PRD workflows
- [ ] Documentation for each tool
- [ ] Example workflows demonstrating orchestration
- [ ] At least 2 external adapters per integration point (chat, ticketing)
