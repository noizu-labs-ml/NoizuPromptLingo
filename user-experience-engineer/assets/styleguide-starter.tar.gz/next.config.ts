import type { NextConfig } from "next";
import path from "path";

// Resolve @styleguide-engine/ alias through the installed npm package
const pkgRoot = path.dirname(require.resolve("@the-robot-lives/styleguide/components"));
const engineSrc = path.resolve(pkgRoot, "dist", "engine-src");

const nextConfig: NextConfig = {
  output: "export",
  transpilePackages: ["@the-robot-lives/styleguide"],
  webpack: (config) => {
    config.resolve.alias["@styleguide-engine"] = engineSrc;
    return config;
  },
};

export default nextConfig;
