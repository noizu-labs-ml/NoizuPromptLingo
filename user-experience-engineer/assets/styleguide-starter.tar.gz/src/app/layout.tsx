import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Project Name",
  description: "Built with styleguide-starter",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-design-theme="style-guide">
      <body>{children}</body>
    </html>
  );
}
